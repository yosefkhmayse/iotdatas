const express = require('express');
const mongoose = require('mongoose');

const port = 5858;
const app = express();
app.use(express.json());
app.set("view engine", "ejs");
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: false}));

const path = require('path');
app.use(express.static(path.join(__dirname, "css")));

require('dotenv').config();

mongoose.connect(process.env.mongoString);
const database = mongoose.connection
database.on('error', (error) => {
    console.log(error)
})

database.once('connected', () => {
    console.log('Database Connected');
})

//--- connecting routers ------------------------
const calls_rtr=require('./routes/IotRtr');
app.use('/C', calls_rtr);

//------------------------------------------------
app.listen(port, () => { console.log(`Now listening on port ${port}`);
});



