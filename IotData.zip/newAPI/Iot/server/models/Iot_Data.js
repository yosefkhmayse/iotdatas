const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({
    Relay_Work_Time: {
        required: true,
        type: Number
    },
    Light_Sensor_Time: {
        required: true,
        type: Number
    },
    Light_Sensor_Value: {

        type: Number
    },
    Led_Work_Time: {
        required: true,
        type: Number
    },
    Stop_Working_Time: {
        required: true,
        type: Number
    }
  
});

module.exports = mongoose.model('Iot_Data', dataSchema)
