const express = require("express");
const router = express.Router();
module.exports = router;
const callsModel = require("../models/Iot_Data");

router.get('/Add', (req, res) => {
  res.render("callAdd", {
    pageTitle: "Iot Working Data",
    item: {}
  });
});

router.post('/Add', async (req, res) => {
  const modelData = new callsModel({
    Relay_Work_Time: req.body.Relay_Work_Time,
    Light_Sensor_Time: req.body.Light_Sensor_Time,
    Light_Sensor_Value: req.body. Light_Sensor_Value,
    Led_Work_Time: req.body.Led_Work_Time,
    Stop_Working_Time: req.body.Stop_Working_Time

  });

  try {
    await modelData.save();
    res.redirect(`/C/Edit?id=${modelData._id}`); // Redirect to the Edit route with the newly created ID
  } catch (error) {
    console.error(error);
    res.status(500).send("An error occurred while saving the data.");
  }
});

router.get('/Edit', async (req, res) => {
  let item_data = await callsModel.findById(req.query.id);
  res.render("callAdd", {
    pageTitle: "Iot Working Data",
    item: item_data
  });
});

router.post('/Edit', async (req, res) => {
  const modelData = {
    Relay_Work_Time: req.body.Relay_Work_Time,
    Light_Sensor_Time: req.body.Light_Sensor_Time,
    Light_Sensor_Value: req.body. Light_Sensor_Value,
    Led_Work_Time: req.body.Led_Work_Time,
    Stop_Working_Time: req.body.Stop_Working_Time
  };

  try {
    let item_data = await callsModel.findByIdAndUpdate(req.query.id, modelData);
    res.redirect(`/C/Edit?id=${req.query.id}`); // Redirect to the Edit route with the same ID
  } catch (error) {
    console.error(error);
    res.status(500).send("An error occurred while updating the data.");
  }
});


